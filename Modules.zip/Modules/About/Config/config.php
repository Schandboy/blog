<?php

return [
    'name' => 'About'
];
