<footer class="footer footer-black  footer-white ">
    <div class="container">
        <div class="row">
            <nav class="footer-nav">
                <ul>
                    <li>
                        <a href="{{url('/')}}">Sahas Blog</a>
                    </li>
                    <li>
                        <a href="{{url('/')}}#blogs">Blog</a>
                    </li>
                    <li>
                        <a href="https://www.msrsn.com" target="_blank">MSRSN School</a>
                    </li>
                </ul>
            </nav>
            <div class="credits ml-auto">
          <span class="copyright">
            ©
            <script>
              document.write(new Date().getFullYear())
            </script>, made by Er. Sahas Dangol
          </span>
            </div>
        </div>
    </div>
</footer>