<?php

return [
    'name' => 'Frontend'
];
